# Sycophancy report

main.tex is the report source. main.pdf is the verified compiled output.
The document uses the standard 10pt article class, its default margins and spacing,
and bundled Computer Modern-derived fonts for reproducible offline XeTeX builds.

Compile with XeLaTeX (xelatex main.tex, twice) or Tectonic (tectonic main.tex).
In Overleaf, select XeLaTeX as the compiler. Keep fonts/ and figures/ beside main.tex.

All four figures are vector PDFs with their SVG originals in figures/.
Their committed source summaries are in data/.
Figure 2 is development cross-validation over four token positions; other probe
performance comparisons in the report use held-out test results unless specified.
